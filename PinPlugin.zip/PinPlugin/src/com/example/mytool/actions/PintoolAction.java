package com.example.mytool.actions;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.console.ConsolePlugin;
import org.eclipse.ui.console.IConsole;
import org.eclipse.ui.console.MessageConsole;
import org.eclipse.ui.console.MessageConsoleStream;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.ui.IFileEditorInput;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Our sample action implements workbench action delegate.
 * The action proxy will be created by the workbench and
 * shown in the UI. When the user tries to use the action,
 * this delegate will be created and execution will be 
 * delegated to it.
 * @see IWorkbenchWindowActionDelegate
 */
@SuppressWarnings("unused")
public class PintoolAction implements IWorkbenchWindowActionDelegate {

    IWorkbenchWindow window;

    /**
     * The constructor.
     */
    public PintoolAction() {
    }

    public StringBuffer executeAction(String cmd) {
        Process p;
        StringBuffer output = new StringBuffer();
        try {
            p = Runtime.getRuntime().exec(cmd);
            p.waitFor();
            BufferedReader reader = 
                new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = "";

            while ((line = reader.readLine()) != null) {
                output.append(line + "\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return output;
    }

    /**
     * The action has been activated. The argument of the
     * method represents the 'real' action sitting
     * in the workbench UI.
     * @see IWorkbenchWindowActionDelegate#run
     */
    public void run(IAction action) {

        // Displaying output in the Eclipse console on which the plugin will run
        MessageConsole myConsole = new MessageConsole("PIN Analyzer Report", null);
        ConsolePlugin.getDefault().getConsoleManager().addConsoles(new IConsole[]{myConsole});
        MessageConsoleStream out = myConsole.newMessageStream();

        // Obtaining the current active application on which PIN will be injected
        String activeProjectPath, activeProjectName;
        IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
        IEditorPart editorPart = activePage.getWorkbenchWindow().getActivePage().getActiveEditor();
        if (editorPart != null) {
            IFileEditorInput input = (IFileEditorInput) editorPart.getEditorInput();
            IFile file = input.getFile();
            String ext = file.getFileExtension();
            IProject activeProject = file.getProject();
            activeProjectPath = activeProject.getLocationURI().toString().substring(5);
            activeProjectName = activeProject.getName();

            String cmd, getAction;
            getAction = action.getText();
            switch (getAction) {
                case "CFG":
                    out.println("You have selected CFG\n");
                    if (ext.equals("cpp")) {
                        cmd = "g++ " + input.getFile().getLocation() + " -lpthread -lm ";
                        out.println(executeAction(cmd).toString());
                        cmd = "./CFG.sh";
                        out.println(executeAction(cmd).toString());
                        out.println("CFG generation has been completed");
                    } else if (ext.equals("c")) {
                        cmd = "gcc " + input.getFile().getLocation() + " -lpthread -lm ";
                        out.println(executeAction(cmd).toString());
                        cmd = "./CFG.sh";
                        out.println(executeAction(cmd).toString());
                        out.println("CFG generation has been completed");
                    }
                    break;

                case "Functional Call Tree":
                    out.println("You have selected Functional Call Tree\n");
                    if (ext.equals("cpp")) {
                        cmd = "g++ " + input.getFile().getLocation() + " -lpthread -lm ";
                        out.println(executeAction(cmd).toString());
                        cmd = "./Functional_Call_Tree.sh";
                        out.println(executeAction(cmd).toString());
                        out.println("Functional Call Tree generation has been completed");
                    } else if (ext.equals("c")) {
                        cmd = "gcc " + input.getFile().getLocation() + " -lpthread -lm ";
                        out.println(executeAction(cmd).toString());
                        cmd = "./Functional_Call_Tree.sh";
                        out.println(executeAction(cmd).toString());
                        out.println("Functional Call Tree generation has been completed");
                    }
                    break;

                case "UnitTest":
                    out.println("You have selected UnitTest\n");
                    if (ext.equals("cpp")) {
                        cmd = "g++ " + input.getFile().getLocation() + " -lpthread -lm ";
                        out.println(executeAction(cmd).toString());
                        cmd = "./UnitTest.sh";
                        out.println(executeAction(cmd).toString());
                        out.println("UnitTest execution has been completed");
                    } else if (ext.equals("c")) {
                        cmd = "gcc " + input.getFile().getLocation() + " -lpthread -lm ";
                        out.println(executeAction(cmd).toString());
                        cmd = "./UnitTest.sh";
                        out.println(executeAction(cmd).toString());
                        out.println("UnitTest execution has been completed");
                    }
                    break;

                case "Thread Model":
                    out.println("You have selected Thread Model\n");
                    if (ext.equals("cpp")) {
                        cmd = "g++ " + input.getFile().getLocation() + " -lpthread -lm ";
                        out.println(executeAction(cmd).toString());
                        cmd = "./Thread_Model.sh";
                        out.println(executeAction(cmd).toString());
                        out.println("Thread Model generation has been completed");
                    } else if (ext.equals("c")) {
                        cmd = "gcc " + input.getFile().getLocation() + " -lpthread -lm ";
                        out.println(executeAction(cmd).toString());
                        cmd = "./Thread_Model.sh";
                        out.println(executeAction(cmd).toString());
                        out.println("Thread Model generation has been completed");
                    }
                    break;
            }

        } else {
            MessageDialog.openError(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Error", "You must first open the project in the editor...");
            return;
        }

    }

    /**
     * Selection in the workbench has been changed. We
     * can change the state of the 'real' action here
     * if we want, but this can only happen after 
     * the delegate has been created.
     * @see IWorkbenchWindowActionDelegate#selectionChanged
     */
    public void selectionChanged(IAction action, ISelection selection) {
    }

    /**
     * We can use this method to dispose of any system
     * resources we previously allocated.
     * @see IWorkbenchWindowActionDelegate#dispose
     */
    public void dispose() {
        System.out.println("Disposed\n");
    }

    /**
     * We will cache window object in order to
     * be able to provide parent shell for the message dialog.
     * @see IWorkbenchWindowActionDelegate#init
     */
    public void init(IWorkbenchWindow window) {
        this.window = window;
    }
}
